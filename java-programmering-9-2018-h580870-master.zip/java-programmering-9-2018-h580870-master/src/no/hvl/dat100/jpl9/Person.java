package no.hvl.dat100.jpl9;

public abstract class Person {
	
	protected String etternamn;
	protected String fornamn;
	protected long fodselsnummer;
	
	
	public Person() {
		etternamn = "";
		fornamn = "";
		fodselsnummer = 0;
	}

	public Person(String etternamn, String fornamn, long fodselsnummer) {
		// TODO
		this.etternamn = etternamn;
		this.fornamn = fornamn;
		this.fodselsnummer = fodselsnummer;
		//throw new RuntimeException("Person constructor not implemented");
	}

	public String getEtternamn() {
		// TODO
		return etternamn;
		//throw new RuntimeException("getEtternamn not implemented");
	}

	public void setEtternamn(String etternamn) {
		// TODO
		this.etternamn = etternamn;
		//throw new RuntimeException("setEtternamn not implemented");
	}

	public String getFornamn() {
		// TODO
		return fornamn;
		//throw new RuntimeException("getFornamn not implemented");
	}

	public void setFornamn(String fornamn) {
		// TODO
		this.fornamn = fornamn;
		//throw new RuntimeException("setFornamn not implemented");
	}

	public void setFodselsnummer(long fodselsnummer) {
		// TODO
		this.fodselsnummer = fodselsnummer;
		//throw new RuntimeException("setFodselsnummer not implemented");
	}

	public long getFodselsnummer() {
		// TODO
		return fodselsnummer;
		//throw new RuntimeException("getFodselsnummer not implemented");
	}

	public boolean erLik(Person person) {
		// TODO
		if (this.fodselsnummer == person.fodselsnummer)
			return true;
		else
			return false;
		//throw new RuntimeException("erLik not implemented");
	}
	
	public boolean erKvinne() {
		// TODO
		String temp = Long.toString(fodselsnummer);
		String temp2 = temp.substring(8, 9);
		int kjonnstal = Integer.parseInt(temp2);
		
		if (kjonnstal % 2 == 0)
			return true;
		else
			return false;
		//throw new RuntimeException("erKvinne not implemented");
	}

	public boolean erMann() {
		// TODO
		String temp = Long.toString(fodselsnummer);
		String temp2 = temp.substring(8, 9);
		int kjonnstal = Integer.parseInt(temp2);
		
		if (kjonnstal % 2 == 1)
			return true;
		else
			return false;
		//throw new RuntimeException("erMann not implemented");
	}
	
	@Override
	public String toString() {
		// TODO
		return fodselsnummer + "\n" + etternamn + "\n" + fornamn + "\n";
		//throw new RuntimeException("toString not implemented");
	}
}
