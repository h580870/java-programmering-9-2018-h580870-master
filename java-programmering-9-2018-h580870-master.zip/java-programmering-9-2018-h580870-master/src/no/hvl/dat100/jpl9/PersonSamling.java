package no.hvl.dat100.jpl9;

public class PersonSamling {
	
	private Person[] tabell;
	private int nesteledig;
	private int antall;
	
	public PersonSamling() {
		// TODO
		tabell = new Person[20];
		nesteledig = 0;
		//throw new RuntimeException("PersonSamling() constructor not implemented");
	}

	public PersonSamling(int lengde) {
		// TODO
		tabell = new Person[lengde];
		nesteledig = 0;
		//throw new RuntimeException("PersonSamling() constructor not implemented");
	}

	public int getAntall() {
		// TODO
		return antall;
		//throw new RuntimeException("getAntall not implemented");
	}

	// DO NOT TOUCH - FOR TESTING PURPOSES ONLY
	public void setAntall(int antall) {
		nesteledig = antall;
	}
	
	public Person[] getSamling() {
		// TODO
		return tabell;
		//throw new RuntimeException("getSamling() not implemented");
	}

	public int finnPerson(Person p) {
		// TODO
		boolean funnet = false;
		int pos = 0;
		while (pos<nesteledig && !funnet) {
			if (tabell[pos].erLik(p))
				funnet = true;
			else
				pos++;
		}
		if (funnet)
			return pos;
		else
			return -1;
		//throw new RuntimeException("finnPerson not implemented");
	}

	public boolean finnes(Person p) {
		// TODO
		if(finnPerson(p) == -1)
			return false;
		else
			return true;
		//throw new RuntimeException("finnes not implemented");
	}

	public boolean ledigPlass() {
		// TODO
		boolean ledigPlass = false;
		
		while (nesteledig<tabell.length && !ledigPlass) {
			if (tabell[nesteledig] == null)
				ledigPlass = true;
			else {
				nesteledig++;
			}
		}
		return ledigPlass;
		//throw new RuntimeException("ledigPlass not implemented");
	}

	public boolean leggTil(Person p) {
		// TODO
		boolean ny = !finnes(p);
		
		if (ny && nesteledig < tabell.length) {
			tabell[nesteledig] = p;
			nesteledig ++;
			antall++;
			return true;
		} else
			return false;
		
		//throw new RuntimeException("leggTil not implemented");
	}
	
	public String toString() {
		// TODO
		String s = getAntall() + "\n";
		for (int i = 0; i<nesteledig; i++) {
			s += tabell[i];
		}
		return s;
		//throw new RuntimeException("toString not implemented");
	}

	public void utvid() {
		
		// TODO
		throw new RuntimeException("utvid not implemented");
	}

	
	public boolean leggTilUtvid(Person p) {

		// TODO
		throw new RuntimeException("leggTilUtvid not implemented");
	}

	public void slett(Person p) {

		// TODO
		throw new RuntimeException("slett not implemented");
	}
}